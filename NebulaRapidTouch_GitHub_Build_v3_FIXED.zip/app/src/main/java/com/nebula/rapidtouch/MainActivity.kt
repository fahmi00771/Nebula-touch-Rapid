package com.nebula.rapidtouch

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
            setBackgroundColor(Color.rgb(9, 9, 20))
        }
        fun text(s: String, size: Float = 16f) = TextView(this).apply {
            this.text = s; textSize = size; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(text("NEBULA RAPID TOUCH", 24f).apply { setTextColor(0xFFB782FF.toInt()) })
        root.addView(text("Hold the floating button to repeat taps at one fixed screen point. Release to stop."))
        root.addView(text("Target X coordinate (screen pixels)"))
        val x = EditText(this).apply { inputType = 2; setSingleLine(); setTextColor(Color.WHITE); setText(prefs.getInt("x", resources.displayMetrics.widthPixels / 2).toString()) }
        root.addView(x, ViewGroup.LayoutParams(-1, dp(52)))
        root.addView(text("Target Y coordinate (screen pixels)"))
        val y = EditText(this).apply { inputType = 2; setSingleLine(); setTextColor(Color.WHITE); setText(prefs.getInt("y", resources.displayMetrics.heightPixels / 2).toString()) }
        root.addView(y, ViewGroup.LayoutParams(-1, dp(52)))
        root.addView(Button(this).apply { text = "SAVE TAP POSITION"; setOnClickListener {
            val xx = x.text.toString().toIntOrNull(); val yy = y.text.toString().toIntOrNull()
            if (xx != null && yy != null && xx >= 0 && yy >= 0) { prefs.edit().putInt("x", xx).putInt("y", yy).apply(); text = "SAVED" }
            else text = "ENTER VALID PIXEL VALUES"
        } })
        root.addView(Button(this).apply { text = "1 • ALLOW DISPLAY OVER OTHER APPS"; setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } })
        root.addView(Button(this).apply { text = "2 • ENABLE ACCESSIBILITY SERVICE"; setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } })
        root.addView(text("If you grant overlay permission after enabling the service, toggle the service off and on again. Android controls the actual repeat rate.", 13f))
        setContentView(root)
    }
}
