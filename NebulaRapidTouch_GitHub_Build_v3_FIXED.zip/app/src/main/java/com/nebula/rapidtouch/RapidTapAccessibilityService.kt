package com.nebula.rapidtouch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

class RapidTapAccessibilityService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var trigger: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var holding = false
    @Volatile private var gestureInFlight = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (android.provider.Settings.canDrawOverlays(this)) addTrigger()
    }

    private fun addTrigger() {
        if (trigger != null) return
        val button = TextView(this).apply {
            text = "HOLD\nTAP"; textSize = 13f; gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xDD6D28D9.toInt())
            setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { holding = true; sendNextTap(); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { holding = false; true }
                    else -> true
                }
            }
        }
        val params = WindowManager.LayoutParams(76, 76,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 220 }
        wm.addView(button, params); trigger = button
    }

    private fun sendNextTap() {
        if (!holding || gestureInFlight) return
        gestureInFlight = true
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val x = prefs.getInt("x", resources.displayMetrics.widthPixels / 2).toFloat()
        val y = prefs.getInt("y", resources.displayMetrics.heightPixels / 2).toFloat()
        val path = Path().apply { moveTo(x, y); lineTo(x + 0.1f, y + 0.1f) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 1)).build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(description: GestureDescription?) {
                gestureInFlight = false
                if (holding) handler.post { sendNextTap() }
            }
            override fun onCancelled(description: GestureDescription?) {
                gestureInFlight = false
                if (holding) handler.postDelayed({ sendNextTap() }, 10)
            }
        }, handler)
        if (!accepted) {
            gestureInFlight = false
            if (holding) handler.postDelayed({ sendNextTap() }, 10)
        }
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() { holding = false }
    override fun onDestroy() {
        holding = false
        trigger?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        trigger = null
        super.onDestroy()
    }
}
